import glob
import sys
import os
import subprocess

n = 0
for crd in glob.glob('conf1/*.crd'):
    line = open(crd, 'r').readlines()[:6][-1].rstrip()
    #output = subprocess.Popen(["grep","'%s'" % line, "*"])
    output = subprocess.check_output("""grep -r '%s' * | wc -l""" % line, shell=True)
    duplicated = int(output.strip())
    if duplicated > 1:
        n += 1
        print n

print n
for crd in glob.glob('conf2/*.crd'):
    line = open(crd, 'r').readlines()[:6][-1].rstrip()
    #output = subprocess.Popen(["grep","'%s'" % line, "*"])
    output = subprocess.check_output("""grep -r '%s' * | wc -l""" % line, shell=True)
    duplicated = int(output.strip())
    if duplicated > 1:
        n += 1
        print n

print n
